package org.lxveyanx.trajectorymod;

import net.fabricmc.api.ModInitializer;

public class Trajectorymod implements ModInitializer {

    @Override
    public void onInitialize() {
    }
}
